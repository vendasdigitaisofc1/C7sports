
import React from 'react';
import { ShieldCheck, Cpu, Globe, Headphones, TrendingUp, BarChart } from 'lucide-react';

const benefits = [
  {
    title: 'Scanner de Odds',
    description: 'Monitoramento em tempo real de mais de 500 casas de apostas globais.',
    icon: BarChart
  },
  {
    title: 'Comunidade VIP',
    description: 'Operações espelhadas com traders que vivem exclusivamente do mercado.',
    icon: Globe
  },
  {
    title: 'Cálculo de Kelly',
    description: 'Gestão de banca científica para maximizar lucros e minimizar riscos.',
    icon: TrendingUp
  },
  {
    title: 'Alertas de Valor',
    description: 'Sinais via Telegram e Terminal com alta taxa de acerto (+80%).',
    icon: Cpu
  }
];

export const Benefits: React.FC = () => {
  return (
    <section className="py-24 bg-gradient-to-b from-transparent to-[#0a0a0a]">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {benefits.map((benefit, idx) => (
            <div key={idx} className="group text-center">
              <div className="w-20 h-20 mx-auto mb-8 relative">
                <div className="absolute inset-0 bg-gradient-to-br from-red-600 to-orange-600 rounded-3xl opacity-20 blur-xl group-hover:opacity-40 transition-opacity"></div>
                <div className="relative w-full h-full bg-white/5 border border-white/10 rounded-3xl flex items-center justify-center transition-transform group-hover:scale-110 group-hover:border-white/20">
                  <benefit.icon className="text-white/80 group-hover:text-white transition-colors" size={32} />
                </div>
              </div>
              <h4 className="text-xl font-bold mb-4">{benefit.title}</h4>
              <p className="text-white/40 text-sm leading-relaxed max-w-[250px] mx-auto">
                {benefit.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
