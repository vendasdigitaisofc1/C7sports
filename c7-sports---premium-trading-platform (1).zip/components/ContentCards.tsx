
import React from 'react';
import { Play, Zap, Shield, BarChart3, Search, Flame } from 'lucide-react';
import { VideoData } from '../App';

interface ContentCardsProps {
  onSelectVideo: (video: VideoData) => void;
  library: VideoData[];
}

const COMMON_THUMBNAIL = 'https://i.ytimg.com/vi/S3I_8y_P5W0/maxresdefault.jpg';

export const ContentCards: React.FC<ContentCardsProps> = ({ onSelectVideo, library }) => {
  return (
    <section className="py-40 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-24">
          <h2 className="text-4xl md:text-6xl font-black tracking-tight mb-6 uppercase">MÓDULOS EM <span className="fire-text italic">EBULIÇÃO.</span></h2>
          <p className="text-white/30 max-w-xl mx-auto uppercase text-[10px] font-bold tracking-[0.3em]">Domine o calor das operações de elite</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 grid-rows-2 gap-6 h-auto md:h-[800px]">
          {/* Box 1 - Destaque Masterclass */}
          <div 
            onClick={() => onSelectVideo(library[0])}
            className="md:col-span-2 md:row-span-2 group relative rounded-[3.5rem] overflow-hidden cursor-pointer border border-white/5 shadow-2xl transition-all hover:scale-[1.02] hover:border-red-500/50 glow-fire"
          >
            <img src={COMMON_THUMBNAIL} className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-110 group-hover:opacity-40 transition-all duration-1000" alt="" />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-red-950/40 to-transparent"></div>
            
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="w-24 h-24 fire-gradient rounded-full flex items-center justify-center text-white shadow-[0_0_60px_rgba(255,30,30,0.6)] animate-pulse">
                <Play size={40} fill="currentColor" />
              </div>
            </div>

            <div className="absolute bottom-12 left-12 right-12">
              <div className="w-16 h-16 fire-gradient rounded-2xl flex items-center justify-center mb-8 shadow-xl">
                <Flame className="text-white" size={32} />
              </div>
              <h3 className="text-5xl font-black mb-6 leading-tight uppercase tracking-tighter">THERMAL <br /> SCANNER.</h3>
              <p className="text-white/60 text-lg leading-relaxed max-w-xs">Aprenda a encontrar valor onde o mercado está superaquecido.</p>
            </div>
          </div>

          {/* Box 2 - Sinais Live */}
          <div 
            onClick={() => onSelectVideo(library[1] || library[0])}
            className="md:col-span-2 group relative rounded-[3rem] overflow-hidden cursor-pointer border border-white/5 transition-all hover:scale-[1.02] hover:border-orange-500/50"
          >
            <img src={COMMON_THUMBNAIL} className="absolute inset-0 w-full h-full object-cover opacity-40 group-hover:scale-105 transition-all duration-700" alt="" />
            <div className="absolute inset-0 bg-gradient-to-r from-black via-orange-950/60 to-transparent"></div>
            
            <div className="relative h-full p-10 flex items-center justify-between">
              <div>
                <div className="w-12 h-12 bg-orange-600/20 rounded-xl flex items-center justify-center mb-6 border border-orange-500/20">
                  <Zap className="text-orange-500" size={24} />
                </div>
                <h3 className="text-3xl font-black mb-2 uppercase tracking-tighter">SINAIS INCENDIÁRIOS</h3>
                <p className="text-white/40 text-sm max-w-[200px]">Operações explosivas com pressão térmica de odds.</p>
              </div>
              <div className="w-20 h-20 fire-gradient rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all scale-50 group-hover:scale-100 shadow-xl">
                <Play size={24} fill="white" className="ml-1" />
              </div>
            </div>
          </div>

          {/* Box 3 - Big Data */}
          <div 
            onClick={() => onSelectVideo(library[2] || library[0])}
            className="group relative rounded-[3rem] overflow-hidden cursor-pointer border border-white/5 transition-all hover:scale-[1.02] hover:border-red-500/30"
          >
            <img src={COMMON_THUMBNAIL} className="absolute inset-0 w-full h-full object-cover opacity-30 grayscale group-hover:grayscale-0 group-hover:opacity-50 transition-all duration-700" alt="" />
            <div className="absolute inset-0 bg-gradient-to-t from-red-950 to-transparent"></div>
            
            <div className="relative h-full p-10 flex flex-col justify-end">
              <div className="w-12 h-12 bg-red-600/20 rounded-xl flex items-center justify-center mb-4 border border-red-500/20">
                <BarChart3 className="text-red-500" size={24} />
              </div>
              <h3 className="text-xl font-black mb-1 uppercase">DATA HEATMAP</h3>
              <p className="text-white/40 text-[10px] leading-relaxed uppercase tracking-widest">Análise de Pontos Quentes</p>
            </div>
          </div>

          {/* Box 4 - Gestão */}
          <div 
            onClick={() => onSelectVideo(library[3] || library[0])}
            className="group relative rounded-[3rem] overflow-hidden cursor-pointer border border-white/5 transition-all hover:scale-[1.02] fire-gradient"
          >
            <img src={COMMON_THUMBNAIL} className="absolute inset-0 w-full h-full object-cover mix-blend-overlay opacity-50" alt="" />
            
            <div className="relative h-full p-10 flex flex-col justify-end">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-4 backdrop-blur-md">
                <Shield className="text-white" size={24} />
              </div>
              <h3 className="text-xl font-black mb-1 uppercase text-white">FORNALHA STAKE</h3>
              <p className="text-white/80 text-[10px] leading-relaxed uppercase tracking-widest">Blindagem de Banca</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
