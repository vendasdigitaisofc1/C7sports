
import React from 'react';
import { Flame, Send, Youtube, Instagram } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="py-24 border-t border-red-500/10 bg-[#030303] relative overflow-hidden">
      <div className="absolute bottom-0 left-0 w-full h-64 bg-gradient-to-t from-red-600/5 to-transparent pointer-events-none"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-start gap-12 mb-20">
          <div className="max-w-md">
            <div className="flex items-center gap-3 mb-8 group">
              <div className="w-10 h-10 fire-gradient rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                <span className="text-white font-black italic text-lg">C7</span>
              </div>
              <span className="text-2xl font-black tracking-tighter uppercase flex items-center gap-2">
                SPORTS <Flame className="text-red-500" size={18} />
              </span>
            </div>
            <p className="text-white/40 text-sm leading-relaxed mb-8">
              A C7 SPORTS é o epicentro da inteligência em trading esportivo. Combinamos algoritmos de elite com educação de alto padrão para forjar os traders mais lucrativos do mercado.
            </p>
            <div className="flex gap-4">
              {[Send, Youtube, Instagram].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:fire-gradient transition-all hover:scale-110 group border border-white/5">
                  <Icon size={18} className="text-white/40 group-hover:text-white" />
                </a>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-16">
            <div className="flex flex-col gap-5">
              <span className="font-black text-[10px] uppercase tracking-[0.3em] fire-text">Terminal</span>
              <a href="#" className="text-sm text-white/50 hover:text-white transition-colors">Scanner Térmico</a>
              <a href="#" className="text-sm text-white/50 hover:text-white transition-colors">Calculadora EV+</a>
              <a href="#" className="text-sm text-white/50 hover:text-white transition-colors">Heatmap de Odds</a>
            </div>
            <div className="flex flex-col gap-5">
              <span className="font-black text-[10px] uppercase tracking-[0.3em] fire-text">Educação</span>
              <a href="#" className="text-sm text-white/50 hover:text-white transition-colors">Masterclass</a>
              <a href="#" className="text-sm text-white/50 hover:text-white transition-colors">Mentoria VIP</a>
              <a href="#" className="text-sm text-white/50 hover:text-white transition-colors">Live Trading</a>
            </div>
            <div className="flex flex-col gap-5">
              <span className="font-black text-[10px] uppercase tracking-[0.3em] fire-text">Suporte</span>
              <a href="#" className="text-sm text-white/50 hover:text-white transition-colors">FAQ</a>
              <a href="#" className="text-sm text-white/50 hover:text-white transition-colors">Canal Telegram</a>
              <a href="#" className="text-sm text-white/50 hover:text-white transition-colors">Aviso de Risco</a>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center pt-12 border-t border-white/5 gap-8">
          <p className="text-[9px] text-white/20 uppercase tracking-[0.25em] text-center md:text-left leading-loose max-w-4xl">
            © 2024 C7 SPORTS TECHNOLOGIES. O TRADING ESPORTIVO ENVOLVE RISCO REAL DE CAPITAL. ESTEJA CIENTE DE QUE O DESEMPENHO PASSADO NÃO É GARANTIA DE RETORNO FUTURO. OPÈRE SEMPRE COM RESPONSABILIDADE E DISCIPLINA. PROIBIDO PARA MENORES DE 18 ANOS.
          </p>
          <div className="flex items-center gap-2 px-4 py-2 bg-red-600/10 border border-red-500/20 rounded-full">
             <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse shadow-[0_0_8px_#ff0000]"></div>
             <span className="text-[9px] font-black text-red-500 uppercase tracking-widest">Sistemas Estáveis</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
