
import React from 'react';
import { TrendingUp, User, Flame } from 'lucide-react';

interface HeaderProps {
  isScrolled: boolean;
}

export const Header: React.FC<HeaderProps> = ({ isScrolled }) => {
  return (
    <header className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-500 ${
      isScrolled ? 'py-4' : 'py-8'
    }`}>
      <div className="container mx-auto px-6">
        <div className={`flex items-center justify-between px-6 py-3 rounded-2xl border transition-all duration-500 ${
          isScrolled 
          ? 'bg-[#0a0a0a]/80 backdrop-blur-xl border-red-500/20 shadow-[0_10px_40px_rgba(255,30,30,0.15)]' 
          : 'bg-transparent border-transparent'
        }`}>
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 fire-gradient rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(255,30,30,0.5)]">
              <span className="text-white font-black text-lg italic">C7</span>
            </div>
            <span className="text-lg font-extrabold tracking-tight uppercase group flex items-center gap-1">
              SPORTS <Flame size={14} className="text-orange-500 opacity-0 group-hover:opacity-100 transition-opacity" />
            </span>
          </div>

          <nav className="hidden lg:flex items-center gap-10">
            {['Estratégias', 'Ao Vivo', 'Gestão', 'Analytics'].map((item) => (
              <a 
                key={item} 
                href={`#${item.toLowerCase()}`} 
                className="text-[13px] font-bold text-white/50 hover:text-white transition-all uppercase tracking-widest relative group"
              >
                {item}
                <span className="absolute -bottom-1 left-0 w-0 h-[2px] fire-gradient transition-all group-hover:w-full"></span>
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-6">
            <button className="hidden sm:flex items-center gap-2 text-xs font-bold text-white/60 hover:text-orange-400 transition-colors uppercase tracking-widest">
              <User size={14} className="text-red-500" />
              Entrar
            </button>
            <button className="fire-gradient text-white px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-tighter hover:scale-105 transition-all active:scale-95 shadow-[0_10px_20px_rgba(255,30,30,0.2)]">
              Começar Agora
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
