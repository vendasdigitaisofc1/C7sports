
import React from 'react';
import { Play, ArrowUpRight, Activity, Flame } from 'lucide-react';

interface HeroProps {
  onWatchClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onWatchClick }) => {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center pt-20 overflow-hidden">
      {/* Ticker de Trading em Tempo Real */}
      <div className="absolute top-24 left-0 w-full overflow-hidden border-y border-red-500/10 py-3 bg-red-900/5 backdrop-blur-md z-20">
        <div className="flex whitespace-nowrap animate-ticker">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="flex gap-12 px-6 items-center">
              <span className="mono text-[10px] font-bold text-white/40 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shadow-[0_0_8px_rgba(255,142,60,0.8)]"></span>
                REAL MADRID vs MILAN <span className="text-white">BACK FAVORITO @1.85 (GREEN)</span>
              </span>
              <span className="mono text-[10px] font-bold text-white/40 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_8px_rgba(255,30,30,0.8)]"></span>
                PREMIER LEAGUE <span className="text-white">OVER 2.5 GOLS DETECTADO</span>
              </span>
              <span className="mono text-[10px] font-bold text-white/40 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-400 shadow-[0_0_8px_rgba(255,142,60,0.8)]"></span>
                LIVERPOOL HT <span className="text-white">LAY ZEBRA ATIVADO</span>
              </span>
              <span className="mono text-[10px] font-bold text-white/40 flex items-center gap-2">
                <Flame size={10} className="text-red-500 animate-pulse" />
                BANKROLL <span className="text-white">YIELD MENSAL +18.4%</span>
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="container mx-auto px-6 relative z-10 text-center mt-20">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-red-600/10 border border-red-500/20 mb-12 shadow-[0_0_15px_rgba(255,30,30,0.1)]">
          <Activity size={12} className="text-orange-500" />
          <span className="text-[9px] font-black uppercase tracking-[0.3em] text-white/80">Operações em Alta Temperatura</span>
        </div>

        <h1 className="text-7xl md:text-[120px] font-extrabold leading-[0.85] tracking-tighter mb-10">
          INCENDEIE O <br />
          <span className="fire-text italic font-light tracking-[-0.05em]">MERCADO.</span>
        </h1>

        <p className="max-w-xl mx-auto text-white/40 text-lg md:text-xl font-medium mb-16 leading-relaxed">
          O Trading Esportivo levado ao extremo. Use algoritmos de pressão térmica para detectar liquidez antes de todo o mercado.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-8 mb-24">
          <button 
            onClick={onWatchClick}
            className="group relative bg-white text-black px-12 py-5 rounded-full text-xs font-black uppercase tracking-widest transition-all hover:fire-gradient hover:text-white hover:scale-105 active:scale-95 overflow-hidden shadow-[0_20px_40px_rgba(255,30,30,0.2)]"
          >
            <span className="relative z-10 flex items-center gap-3">
              ASSISTIR MASTERCLASS FOGO <Play size={14} fill="currentColor" />
            </span>
          </button>
          
          <button className="text-xs font-black uppercase tracking-widest text-white/40 hover:text-orange-500 transition-all flex items-center gap-3 group">
            ABRIR CONTA TRADER PRO <ArrowUpRight size={16} className="text-red-500 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </button>
        </div>

        {/* Visual de Dashboard Cinemático */}
        <div className="relative max-w-6xl mx-auto">
          <div className="absolute -inset-10 bg-red-600/15 blur-[120px] rounded-full fire-pulse"></div>
          <div className="glass-premium rounded-[3rem] p-2 border-red-500/10 overflow-hidden group glow-fire">
            <div className="rounded-[2.5rem] overflow-hidden aspect-[21/9] relative bg-black">
              <img 
                src="https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&q=80&w=1600" 
                className="w-full h-full object-cover opacity-20 group-hover:opacity-40 transition-opacity duration-1000 group-hover:scale-105 transition-transform duration-[2s]"
                alt="Terminal de Trading"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-red-950/40 via-transparent to-transparent"></div>
              
              <div className="absolute top-8 left-8 flex flex-col gap-2">
                <div className="w-32 h-2 bg-red-600/30 rounded-full"></div>
                <div className="w-20 h-2 bg-orange-600/20 rounded-full"></div>
              </div>
              <div className="absolute bottom-8 right-8 mono text-[10px] text-red-500/40 uppercase tracking-widest">
                HEAT_SIGNAL_V4.2 // SCANNING LIQUIDITY...
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
