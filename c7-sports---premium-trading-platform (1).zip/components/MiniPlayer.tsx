
import React from 'react';
import { Play, X, SkipForward, Volume2, Flame } from 'lucide-react';
import { VideoData } from '../App';

interface MiniPlayerProps {
  activeVideo: VideoData;
  onPlay: () => void;
}

export const MiniPlayer: React.FC<MiniPlayerProps> = ({ activeVideo, onPlay }) => {
  return (
    <div className="fixed bottom-6 right-6 left-6 md:left-auto md:w-[440px] z-[60] animate-in slide-in-from-bottom-10 duration-500">
      <div 
        onClick={onPlay}
        className="glass-premium p-4 rounded-3xl flex items-center gap-4 shadow-2xl relative group border-red-500/10 hover:border-red-500/30 transition-all cursor-pointer glow-fire"
      >
        {/* Close Button */}
        <button 
          onClick={(e) => { e.stopPropagation(); }}
          className="absolute -top-2 -right-2 w-8 h-8 bg-red-600 hover:bg-red-500 rounded-full flex items-center justify-center text-white border border-white/20 shadow-lg transition-all z-10"
        >
          <X size={14} />
        </button>

        {/* Thumbnail */}
        <div className="w-24 h-16 rounded-xl overflow-hidden bg-black relative flex-shrink-0 group/thumb fire-border-animate">
          <img 
            src={activeVideo.thumbnail} 
            alt="Thumb" 
            className="w-full h-full object-cover opacity-70 group-hover/thumb:scale-110 transition-transform" 
          />
          <div className="absolute inset-0 flex items-center justify-center bg-red-950/20 group-hover:bg-transparent transition-colors">
            <div className="w-9 h-9 rounded-full fire-gradient flex items-center justify-center shadow-lg">
              <Play size={16} fill="white" className="text-white ml-0.5" />
            </div>
          </div>
        </div>

        {/* Info */}
        <div className="flex-1 overflow-hidden">
          <h5 className="text-[12px] font-black truncate leading-tight group-hover:text-orange-400 transition-colors uppercase tracking-tight">{activeVideo.title}</h5>
          <div className="flex items-center gap-2 mt-1">
             <Flame size={10} className="text-red-500 animate-pulse" />
             <p className="text-[10px] text-white/40 uppercase tracking-tighter font-black">
                <span className="fire-text">{activeVideo.module}</span> • CONTEÚDO QUENTE
             </p>
          </div>
          
          {/* Progress Bar */}
          <div className="mt-3 h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
            <div className="h-full w-[45%] fire-gradient relative shadow-[0_0_10px_rgba(255,30,30,0.5)]">
               <div className="absolute right-0 top-0 h-full w-8 bg-white/40 blur-md animate-pulse"></div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-3 pr-2 text-white/30 group-hover:text-white/60 transition-colors">
          <Volume2 size={16} className="cursor-pointer hover:text-red-500 transition-colors" />
          <SkipForward size={16} className="cursor-pointer hover:text-red-500 transition-colors" />
        </div>
      </div>
    </div>
  );
};
