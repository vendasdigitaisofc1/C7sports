
import React from 'react';
import { AreaChart, TrendingUp, Cpu, Server, Wallet } from 'lucide-react';

export const Results: React.FC = () => {
  return (
    <section className="py-40 bg-[#020202] relative">
      <div className="container mx-auto px-6">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-20 items-center">
          <div className="lg:w-1/2">
            <span className="mono text-red-500 text-[10px] font-black tracking-[0.4em] mb-6 block uppercase">Sovereign Trading Terminal</span>
            <h2 className="text-5xl md:text-8xl font-black mb-10 leading-[0.85] tracking-tight">
              LUCRO QUE <br /> 
              <span className="font-thin italic opacity-50">ESCALA.</span>
            </h2>
            <div className="grid grid-cols-2 gap-8 mb-12">
               <div className="p-6 rounded-3xl bg-white/5 border border-white/10">
                  <div className="flex items-center gap-3 mb-4 text-red-500">
                    <TrendingUp size={20} />
                    <span className="text-[10px] font-black uppercase tracking-widest text-white/40">ROI Mensal</span>
                  </div>
                  <div className="text-2xl font-black">22.4% Médio</div>
                  <p className="text-[10px] text-white/20 mt-2 uppercase font-bold tracking-tighter">Baseado em Operações Profissionais</p>
               </div>
               <div className="p-6 rounded-3xl bg-white/5 border border-white/10">
                  <div className="flex items-center gap-3 mb-4 text-orange-500">
                    <Wallet size={20} />
                    <span className="text-[10px] font-black uppercase tracking-widest text-white/40">Bankroll</span>
                  </div>
                  <div className="text-2xl font-black">+R$ 1.2M</div>
                  <p className="text-[10px] text-white/20 mt-2 uppercase font-bold tracking-tighter">Volume Gerido pela Comunidade VIP</p>
               </div>
            </div>
            <button className="px-10 py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-[10px] font-black uppercase tracking-[0.2em] transition-all">
              Acessar Relatório de Greens
            </button>
          </div>

          <div className="lg:w-1/2 w-full">
            <div className="glass-premium rounded-[3rem] p-8 border-white/10 shadow-2xl relative">
              <div className="flex items-center justify-between mb-12 border-b border-white/5 pb-6">
                <div className="flex items-center gap-4">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <span className="text-sm font-black uppercase tracking-widest italic tracking-tighter">PROFIT_DYNAMICS_V4</span>
                </div>
                <div className="mono text-[10px] text-white/30 uppercase tracking-widest italic">Live ROI: +18.42%</div>
              </div>

              <div className="space-y-12">
                <div>
                   <div className="flex justify-between items-center mb-4">
                      <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Crescimento de Banca</span>
                      <span className="text-green-500 mono text-xs font-bold">+2.44% Hoje</span>
                   </div>
                   <div className="h-32 flex items-end gap-1.5">
                     {[20, 30, 25, 45, 40, 65, 50, 80, 75, 100].map((h, i) => (
                       <div key={i} className="flex-1 bg-gradient-to-t from-red-600/40 to-red-500/10 rounded-t-sm relative group">
                          <div className="h-full w-full absolute bottom-0 bg-red-500/20 opacity-0 group-hover:opacity-100 transition-opacity" style={{ height: `${h}%` }}></div>
                          <div className="bg-red-500 w-full" style={{ height: `${h/2}%` }}></div>
                       </div>
                     ))}
                   </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  {[
                    { label: 'Drawdown Max', value: '4.2%' },
                    { label: 'Win Rate', value: '72%' },
                    { label: 'Profit Factor', value: '2.8' }
                  ].map((item, i) => (
                    <div key={i} className="text-center p-4 rounded-2xl bg-white/[0.02] border border-white/5">
                      <div className="text-[8px] font-black text-white/20 uppercase tracking-widest mb-1">{item.label}</div>
                      <div className="text-lg font-black mono">{item.value}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
