
import React, { useEffect } from 'react';
import { X, ExternalLink } from 'lucide-react';
import { VideoData } from '../App';

interface VideoModalProps {
  video: VideoData;
  onClose: () => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ video, onClose }) => {
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, []);

  const getEmbedUrl = (url: string) => {
    if (url.includes('vimeo')) {
      return `${url}?autoplay=1&badge=0&autopause=0&player_id=0&app_id=58479&title=0&byline=0&portrait=0`;
    }
    return `${video.videoUrl}?autoplay=1&modestbranding=1&rel=0`;
  };

  const getExternalLink = (url: string) => {
    if (url.includes('vimeo')) {
      return url.replace('player.vimeo.com/video/', 'vimeo.com/');
    }
    return video.videoUrl.replace('embed/', 'watch?v=');
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-10 animate-in fade-in zoom-in duration-300">
      <div 
        className="absolute inset-0 bg-black/90 backdrop-blur-xl cursor-pointer" 
        onClick={onClose}
      ></div>

      <div className="relative w-full max-w-6xl aspect-video rounded-[2rem] overflow-hidden border border-white/10 shadow-[0_0_100px_rgba(239,68,68,0.2)] bg-black">
        <iframe 
          className="w-full h-full"
          src={getEmbedUrl(video.videoUrl)}
          title={video.title}
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        ></iframe>

        <div className="absolute top-6 left-6 right-6 flex items-center justify-between pointer-events-none">
          <div className="bg-black/60 backdrop-blur-md px-4 py-2 rounded-full border border-white/10 flex items-center gap-3">
             <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
             <span className="text-xs font-bold tracking-widest uppercase opacity-80">{video.module}</span>
          </div>

          <div className="flex gap-3 pointer-events-auto">
            <a 
              href={getExternalLink(video.videoUrl)} 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-12 h-12 bg-white/5 hover:bg-white/10 backdrop-blur-md border border-white/10 rounded-full flex items-center justify-center text-white transition-all hover:scale-110"
              title="Ver no Provedor"
            >
              <ExternalLink size={20} />
            </a>
            <button 
              onClick={onClose}
              className="w-12 h-12 bg-red-600 hover:bg-red-500 rounded-full flex items-center justify-center text-white shadow-xl glow-red transition-all hover:scale-110"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        <div className="absolute bottom-6 left-6 right-6 pointer-events-none">
            <h3 className="text-2xl md:text-3xl font-black text-white drop-shadow-lg">{video.title}</h3>
        </div>
      </div>
    </div>
  );
};
