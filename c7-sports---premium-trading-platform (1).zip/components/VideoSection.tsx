
import React from 'react';
import { Play, ListVideo, Clock, Maximize2, Pause, Flame } from 'lucide-react';
import { VideoData } from '../App';

interface VideoSectionProps {
  activeVideo: VideoData;
  library: VideoData[];
  onSelectVideo: (video: VideoData) => void;
  isPlayingInline: boolean;
  setIsPlayingInline: (playing: boolean) => void;
  onMaximize: () => void;
}

export const VideoSection: React.FC<VideoSectionProps> = ({ 
  activeVideo, 
  library, 
  onSelectVideo,
  isPlayingInline,
  setIsPlayingInline,
  onMaximize
}) => {
  const getEmbedUrl = (url: string) => {
    if (url.includes('vimeo')) {
      return `${url}?autoplay=1&badge=0&autopause=0&player_id=0&app_id=58479&title=0&byline=0&portrait=0`;
    }
    const isEmbed = url.includes('embed/');
    const baseUrl = isEmbed ? url : url.replace('watch?v=', 'embed/');
    return `${baseUrl}?autoplay=1&modestbranding=1&rel=0&showinfo=0&iv_load_policy=3`;
  };

  return (
    <section id="video-player" className="py-20 bg-[#050505]">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-8 max-w-7xl mx-auto">
          
          {/* Main Video Area */}
          <div className="flex-1">
            <div className="relative aspect-video rounded-3xl overflow-hidden glass shadow-[0_0_80px_rgba(255,30,30,0.15)] group border border-red-500/20 bg-black glow-fire">
              {!isPlayingInline ? (
                <div 
                  className="absolute inset-0 z-10 cursor-pointer" 
                  onClick={() => setIsPlayingInline(true)}
                >
                  <img 
                    src={activeVideo.thumbnail} 
                    alt={activeVideo.title} 
                    className="w-full h-full object-cover opacity-60 transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 group-hover:bg-red-900/20 transition-all">
                    <button className="w-20 h-20 fire-gradient rounded-full flex items-center justify-center text-white shadow-[0_0_40px_rgba(255,30,30,0.5)] transition-all group-hover:scale-110 mb-4 animate-pulse">
                      <Play size={32} fill="currentColor" className="ml-1" />
                    </button>
                    <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full border border-white/10 opacity-0 group-hover:opacity-100 transition-all translate-y-4 group-hover:translate-y-0">
                      <Flame size={12} className="text-orange-500" />
                      <span className="text-[10px] font-bold tracking-widest uppercase text-white">Iniciar Masterclass de Fogo</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="w-full h-full relative">
                  <iframe 
                    className="w-full h-full"
                    src={getEmbedUrl(activeVideo.videoUrl)}
                    title={activeVideo.title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                  
                  {/* Action Buttons for Inline Player */}
                  <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-30">
                    <button 
                      onClick={() => setIsPlayingInline(false)}
                      className="p-2 bg-black/60 backdrop-blur-md rounded-lg border border-white/10 text-white/70 hover:text-white transition-colors"
                      title="Parar Reprodução"
                    >
                      <Pause size={18} />
                    </button>
                    <button 
                      onClick={onMaximize}
                      className="p-2 fire-gradient rounded-lg text-white shadow-lg glow-fire hover:scale-110 transition-transform"
                      title="Modo Cinema"
                    >
                      <Maximize2 size={18} />
                    </button>
                  </div>
                </div>
              )}

              {/* Tag Status */}
              {!isPlayingInline && (
                <div className="absolute top-6 left-6 fire-gradient px-3 py-1 rounded-md text-[10px] font-black tracking-tighter uppercase italic skew-x-[-10deg] animate-pulse z-20 shadow-lg">
                  CONTEÚDO QUENTE
                </div>
              )}
            </div>
            
            <div className="mt-8 flex flex-col sm:flex-row justify-between items-start gap-4">
              <div className="animate-in fade-in slide-in-from-left duration-700">
                <span className="fire-text font-bold text-xs uppercase tracking-widest mb-2 block">{activeVideo.module}</span>
                <h2 className="text-3xl font-black tracking-tight">{activeVideo.title}</h2>
              </div>
              <div className="flex gap-4">
                <button 
                  onClick={onMaximize}
                  className="px-6 py-2.5 rounded-xl bg-red-950/20 border border-red-500/20 text-xs font-bold hover:bg-red-500/10 hover:border-red-500/40 transition-all flex items-center gap-2"
                >
                  <Maximize2 size={14} />
                  MODO FORNALHA
                </button>
              </div>
            </div>
          </div>

          {/* Library Sidebar */}
          <div className="w-full lg:w-80 flex flex-col gap-4">
            <div className="flex items-center gap-2 mb-2 px-2">
              <Flame size={18} className="text-orange-500" />
              <span className="font-bold text-sm uppercase tracking-tighter">Aulas em Ebulição</span>
            </div>
            
            <div className="flex flex-col gap-3 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
              {library.map((video) => (
                <button 
                  key={video.id}
                  onClick={() => onSelectVideo(video)}
                  className={`flex gap-4 p-3 rounded-2xl transition-all text-left border group/item ${
                    activeVideo.id === video.id 
                    ? 'bg-red-900/10 border-red-500/30 ring-1 ring-red-500/30 shadow-[0_0_15px_rgba(255,30,30,0.1)]' 
                    : 'bg-white/[0.02] border-white/5 hover:bg-white/5'
                  }`}
                >
                  <div className="w-24 h-16 rounded-lg overflow-hidden flex-shrink-0 relative bg-black">
                    <img src={video.thumbnail} className="w-full h-full object-cover opacity-70 group-hover/item:scale-110 transition-transform" alt="" />
                    {activeVideo.id === video.id && (
                       <div className="absolute inset-0 bg-red-600/40 flex items-center justify-center">
                         <div className="flex gap-0.5">
                           <div className="w-1 h-3 bg-white animate-bounce"></div>
                           <div className="w-1 h-4 bg-white animate-bounce [animation-delay:0.2s]"></div>
                           <div className="w-1 h-2 bg-white animate-bounce [animation-delay:0.4s]"></div>
                         </div>
                       </div>
                    )}
                  </div>
                  <div className="flex flex-col justify-center gap-1">
                    <h4 className="text-[11px] font-bold leading-tight line-clamp-2 group-hover/item:text-orange-400 transition-colors">{video.title}</h4>
                    <div className="flex items-center gap-2 opacity-40">
                      <Clock size={10} />
                      <span className="text-[9px] font-medium">{video.duration}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
